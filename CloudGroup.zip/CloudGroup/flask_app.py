# -*- coding: utf-8 -*-
"""
Created on Sat Apr  1 14:13:37 2023

@author: Daniel Matthew
"""

from flask import Flask, render_template, request
import boto3

app = Flask(__name__)
s3 = boto3.client('s3')

@app.route('/')
def upload_form():
    return render_template('upload.html')

@app.route('/', methods=['POST'])
def upload_file():
    file = request.files['file']
    filename = file.filename
    #make sure to put name of bucket we will use here
    s3.upload_fileobj(file, 'grouproj301136330', filename)
    return 'File uploaded successfully!'

